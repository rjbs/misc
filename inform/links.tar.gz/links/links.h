!!!!! NAME
!	links.h 
!	Inform library extension file
!	by Jayson Smith
!	reformatted and extended by Ricardo Signes

!!!!! SYNOPSIS

!	This library provides some classes and the basic interfacing routines and
!	verbs for Spider and Web style linkable objects.  If you have no idea what 
!	I'm talking about, please go play Andrew Plotkin's excellent game, "Spider
!	and Web".  Also, a brief summary can be found in the piece of paper in
!	links.inf, the sample game.

!	Note that this code was not, repeat not, used in Spider and Web.  In fact,
!	S&W was what inspired me to write this library!

!	This library and the sample game may be distributed freely.  Having said
!	that, if you use any of this code in a game, I'd appreciate at least a
!	"Thank you" in your game.

!!!!! NOTES

!	This code is very poorly formatted E.G. no indentation.  Also, it may be
!	written sloppily, but appears not to have much in the way of bugs.  If you do
!	find any bugs, please send me a letter at jaybird@coldmail.com.

!!!!! CLASSES

!!	actuator
!	This class is used for actuators --  e.g.,  buttons, switches, timers, etc,
!	which are used to activate or trigger devices.

!!	device
!	This class is for devices, e.g. beepers, lights, blenders, etc, which can
!	be activated by actuators.

!!	switch
!	As you'd expect, a switch is an actuator that can be turned on and off, and
!	remains in the state to which it was set.  The methods 'switchon' and
!	'switchoff' call the 'turnon' and 'turnoff' routines.

!!	remote
!	A remote is an actuator that can be used remotely to control a device.

!!!!! ATTRIBUTES

!!	malelink
!!	femalelink
!	As is logical, linkable objects connect male-to-female.  A male object can
!	only connect to a female object, and vice versa.  'Tradition' suggests that
!	controls are male and devices are female.

!!!!! METHODS and PROPERTIES

!!	turnon
!!	turnoff
!	This method is called when a device is turned on or off by an actuator.

!!	brief
!	Some objects don't turn on and off, but are just activated briefly at the
!	touch of a button.  A water-fountain, for example, is only 'on' while the
!	button is pushed.  The 'brief' method is called when a device is actuated
!	only briefly, such as by a buttonpush.

!!	baseunit
!	This property tells a remote object to what actuator it is linked.

attribute remotely;
attribute malelink;
attribute femalelink;
fake_action linktake;
fake_action linkdrop;
global temporary;

class actuator
	with before [;
		take:
				linkedtake(self,self.linkto);
		drop:
				linkeddrop(self,self.linkto);
		],
	with after [;
		examine:
			print "It has a ";
			if (self has malelink) print "male ";
			else print "female ";
			print (address) self.linktype, " link, which ";
			if (self.linkto==0) "isn't connected to anything.";
			else print "is connected to ",(a) self.linkto,".^";
		],
	with turnon [;
		if (self.linkto==0) {
			if (self hasnt remotely) "Nothing happens.";
			else "You perceive no other effect.";
		};
		temporary=self.linkto;
		temporary.turnon();
		rtrue;
	],
	with turnoff [;
		if (self.linkto==0) {
			if (self hasnt remotely) "Nothing happens.";
			else "You perceive no other effect.";
		};
		temporary=self.linkto;
		temporary.turnoff();
	],
	with brief [;
		if (self.linkto==0) {
			if (self hasnt remotely) "Nothing happens.";
			else "You perceive no other effect.";
		};
		temporary=self.linkto;
		temporary.brief();
	],
	with linktype 'universal',
	with linkto,
;

class remote
	with baseunit, turnon, turnoff, brief
;

class device
	with before [;
		take:
			linkedtake(self,self.linkto);
		drop:
			linkeddrop(self,self.linkto);
	],
	with after [;
		examine: 
			print "It has a ";
			if (self has malelink) print "male ";
			else print "female ";
			print (address) self.linktype, " link, which ";
			if (self.linkto==0) "isn't connected to anything.";
			else print "is connected to ",(a) self.linkto,".^";
	],
	with linktype 'universal',
	with brief, turnon, turnoff, linkto
;

class switch
class actuator
	has switchable,
	with after [;
		switchon: 
			print "You flip ",(the) self," on.^";
			self.turnon();
			rtrue;
		switchoff: 
			print "You flip ",(the) self," off.^";
			self.turnoff();
			rtrue;
	]
	with linktype 'universal'
;

verb "link" "connect" 
	* noun "to" noun -> link;
verb "unlink" "disconnect"
	* noun -> unlink;

[linksub;
	if (noun has remotely) {
		print (the) noun," doesn't have a link.  It works via ",(the) self.baseunit,".^";
		rtrue;
	};
	if (second has remotely) {
		print (the) second," doesn't have a link.  It works via", (the) second.baseunit,".^";
		rtrue;
	};
	if (
		((noun has malelink) && (second has femalelink)) 
		||
		((noun has femalelink) && (second has malelink))
		&&
		(noun.linktype == second.linktype)
		) {
			link(noun,second);
			rtrue;
	}
	if (noun has malelink && (second has malelink)) {
		"You can't link those together because they both have male links.^";
	}
	if (noun has femalelink && (second has femalelink)) {
		"You can't link those together because they both have female links.";
	}
	if (noun hasnt malelink && (noun hasnt femalelink)) {
		print (the) noun," doesn't have a link, so you can't connect it to anything.^";
		rtrue;
	}
	if (second hasnt malelink && (second hasnt femalelink)) {
		print (the) second," doesn't have a link, so you can't connect anything to it.^";
		rtrue;
	}
	if (noun.linkto~=0) {
		print (the) noun," is already linked to ",(the) noun.linkto,".  You'll have to unlink it first.^";
		rtrue;
	}
	if (second.linkto~=0) {
		print (the) second," is already linked to ",(the) second.linkto,".  You'll have to unlink it first.^";
		rtrue;
	}
	if (noun.linktype ~= second.linktype) {
		print (The) noun, " and ", (the) second, " don't have the same kind of connector.";
		rtrue;
	}
];

[link i j;
	i.linkto=j;
	j.linkto=i;
	print "You link ",(the) i," to ",(the) j,".^";
	if (indirectlycontains(player,i) && (indirectlycontains(player,j) == false)) {
		print "You also let go of ",(the) i,".^";
		move i to parent(player);
	};
	if (indirectlycontains(player,i) == false && (indirectlycontains(player,j))) {
		print "You also let go of ",(the) j,".^";
		move j to parent(player);
	};
	if (i has on) {
		j.turnon();
	}
];

[unlinksub;
	if (noun has remotely) {
		print (the) noun," doesn't have a link.  It works via ", (the) noun.baseunit,".^";
		rtrue;
	};
	if (second==0) {
		if (noun provides linkto) {
			temporary=noun.linkto;
			if (temporary==0) "That isn't linked to anything.^";
			print "You unlink ",(the) noun," from ",(the) temporary,".^";
			noun.linkto=0;
			temporary.linkto=0;
			if (noun has on) {
				temporary.turnoff();
			}
			rtrue;
		}
	}
	else if (noun provides linkto && (second provides linkto)) {
		if (noun.linkto ~= second) "Those aren't linked together.^";
		print "You unlink ",(the) noun," from ",(the) second,".^";
		noun.linkto=0;
		second.linkto=0;
		if (noun has on) {
			second.turnoff();
		}
		rtrue;
	}
	else if (noun provides ~linkto) {
		print (the) noun," doesn't have a link.^";
		rtrue;
	}
	else if (second~=0) {
		if (second provides ~linkto) {
			print (the) second," doesn't have a link.^";
			rtrue;
		}
	}
];

[linkedtake i j;
	if (j==0) rtrue;
	if (i in player) rtrue;
	if (i has static || (i has scenery)) rtrue;
	action=##linktake;
	if (runroutines(j,before) ~= 0 || (j has static || (j has scenery))) {
		print "You'll have to disconnect ",(the) i," from ",(the) j," first.^";
		rtrue;
	}
	else {
		if (runroutines(i,before)~=0 || (i has static || (i has scenery))) {
			print "You'll have to disconnect ",(the) i," from ",(the) j," first.^";
			rtrue;
		}
		else if (j hasnt concealed && j hasnt static) move j to player;
		if (i hasnt static && i hasnt concealed) move i to player;
		action=##linktake;
		if (runroutines(j,after) ~= 0) rtrue;
		print "You take ", (the) i," and ", (the) j," connected to it.^";
		rtrue;
	}
];

[linkeddrop i j;
	if (j==0) rtrue;
	if (i notin player) rtrue;
	action=##linkdrop;
	if (runroutines(j,before)~=0) {
		print "You'll have to disconnect ",(the) i," from ",(the) j," first.^";
		rtrue;
	} else {
		if (runroutines(i,before)~=0) {
			print "You'll have to disconnect ",(the) i," from ",(the) j," first.^";
			rtrue;
		}
		else
			move i to location;
		move j to location;
		action=##linkdrop;
		if (runroutines(j,after)~=0) rtrue;
		print "You drop ",(the) i," and ",(the) j," connected to it.^";
		rtrue;
	}
];
