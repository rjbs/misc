#!/usr/bin/ruby

# checkbook balancer
# $Id: balance.rb,v 1.2 2004/05/19 22:34:43 rjbs Exp $

## CONFIGURATION
libdir   = "/Users/rjbs/code/ruby/balance" # <-- where you put Journal.rb
checkdir = "/Users/rjbs/Documents/ledger"  # <-- where you put ledgers
## END CONFIGURATION

$:.push(libdir)
require "Journal"

journal = Journal::new
Dir.foreach(checkdir) { |year|
	unless year =~ /^\./
		journal.ledger_from_file("#{checkdir}/#{year}")
	end
}

journal.reconcile

puts "Suspected actual balanced: %0.2f" % (journal.balance)
puts "Pending transaction total: %0.2f" % (journal.pending)
puts "Suspected available balanced: %0.2f" % (journal.balance + journal.pending)
puts
puts journal.comment

journal.compile_history
