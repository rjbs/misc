#!/usr/bin/ruby

# checkbook balancer

class Ledger < Array
  def record(date, reason, subreason, amount, pending=false)
	self.push( {
	  'date'      => date, 
	  'reason'    => reason, 
	  'subreason' => subreason, 
	  'amount'    => amount,
	  'pending'   => pending
	} )
  end
end

class Journal
  attr_reader :balance, :history, :pending, :comment
  def initialize
	@comment = Array::new
	@ledgers = Array::new
	@balance = 0.0
	@pending = 0.0
  end
  def ledger_from_file(filename)
	ledger = Ledger::new
	@ledgers.push ledger

	xact_pat = /^
	  ([+-]{1,2})\s+
	  ([0-9.]+)\s+
	  ([0-9a-z]{8})\s+
	  ([a-z]+)(.([a-z]+))?
	  ((\s+)\#\s*(.+))?
	$/x

	File::open(filename).each { |line|
	  line.chomp!
	  #contents = [ sign, amt, date, reason, .subreason, subreason, postmatch, space, comment ]
	  if contents = xact_pat.match(line)
		case contents[1]
		  when '+';
			ledger.record(contents[3], contents[4], contents[5], contents[2].to_f)
		  when '-';
			ledger.record(contents[3], contents[4], contents[5], -(contents[2].to_f))
		  when '++';
			ledger.record(contents[3], contents[4], contents[5], contents[2].to_f, true)
		  when '--';
			ledger.record(contents[3], contents[4], contents[5], -(contents[2].to_f), true)
		end
	  elsif contents = /^\s*$/
		1
	  else
		@comment.push(line)
	  end
	}
  end
  def reconcile
	@balance = 0.0
	@ledgers.each { |ledger|
	  ledger.each { |entry| 
		entry['pending'] ?  @pending += entry['amount'] : @balance += entry['amount'] 
	  }
	}
  end
  def compile_history
	@history = {}
	@ledgers.each { |ledger|
	  ledger.each { |transaction|
		@history[transaction['date']] ||= 0
		@history[transaction['date']] += transaction['amount']
	  }
	}
  end
end
