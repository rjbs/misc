#!/usr/bin/perl

=head1 NAME

Games::Go::Board - A board class for the game of go

=head1 SYNOPSIS

use Games::Go::Board;

$board = Games::Go::Board->new(19);

print $board->text;

open IMAGE, ">board.png";
binmode IMAGE;
print IMAGE $board->png;
close IMAGE;

=head1 DESCRIPTION

=cut

package Games::Go::Board;

use GD;
use constant BLACK			=> 0;
use constant WHITE			=> 1;
use constant MARK_SQUARE	=> 2;
use constant MARK_TRIANGLE	=> 4;
use constant MARK_CIRCLE	=> 8;
use strict;

=head1 CONSTRUCTOR

=item new($lines)

This is the Games::Go::Board constructor.  It's very simple -- it returns a new
board object representing a board, I<$lines> points per edge.

=cut

sub new { 
	my ($class, $lines) = @_;

	my $self = {
		lines	=> $lines,
		stones	=> [],
		marks	=> []
	};

	bless $self, $class;
}

=begin programmer_notes

=item _stars() - star-finding routing

The routing to find star points was inspired by that in GNU Go v3.0.0

In brief, all boards have at least four hoshi, located at the 3-3 points on
boards less than 11x11 and the 4-4 points on larger boards.  Boards with an odd
number of lines have an additional five points, each equidistant from two of
the corner points.  

=end programmer_notes

=cut

sub _stars {
	my ($size) = @_;
	my $stars = [];

	my $corner = ($size > 11 ? 4 : 3);

	push @$stars, (
		[ $corner, $corner ],									[ $size-$corner+1, $corner ],
		[ $corner, $size-$corner+1 ],							[ $size-$corner+1, $size-$corner+1 ]
	);

	if (($size % 2) && ($size>=9)) {
		my $half=($size+1)/2;
		push @$stars, (
									[ $half, $corner ],
			[ $corner, $half ],		[ $half, $half ],			[ $size-$corner+1, $half ],
									[ $half, $size-$corner+1 ]
		);
	}

	return $stars;
	
}

=head1 METHODS

=item text()

This method returns an ASCII diagram of the board.

=cut 

sub text {
	my ($self) = @_;
	
	my ($board, %stone);

	$stone{(BLACK)}='X';
	$stone{(WHITE)}='O';

	for (my $i=0; $i<$self->{lines}; $i++) {
			$board->[$i]=' .' x $self->{lines};
	}

	foreach my $starpoint (@{_stars($self->{lines})}) {
		substr(
			$board->[($starpoint->[0])-1],
			(($starpoint->[1]*2)-1),
			,1
		) = '+';
	}

	sub txt_place_stone {
		my ($color, $x, $y) = @_;

		substr(
			$board->[$y-1],
			(($x*2)-1),
			,1
		) = $stone{$color};
		
	}

	txt_place_stone(BLACK,5,5);
	txt_place_stone(BLACK,5,6);
	txt_place_stone(WHITE,6,5);
	txt_place_stone(WHITE,$self->{lines},$self->{lines});

	return join("\n",@$board) . "\n";

}


=item png($size)

This method returns a PNG image of the board, I<$size> pixles on an edge.  I
have found that standard (19x19) boards smaller than 130 pixels are illegible,
and boards smaller than 225 pixels have poorly-defined star points.

=cut

sub png {
	my ($self,$size) = @_;

		my (%board, %star, %stone);

	$board{min}=int($size * .01);
	$board{max}=int($size * .99);

	$board{grid}->{min}=$board{min} + (($board{max}-$board{min}) / (2 * $self->{lines}));
	$board{grid}->{max}=$board{max} - (($board{max}-$board{min}) / (2 * $self->{lines}));
	$board{grid}->{space}=($board{grid}->{max}-$board{grid}->{min})/($self->{lines}-1);

	$board{img}=GD::Image->new($size,$size);

	$board{color}->{black}=$board{img}->colorAllocate(0,0,0);
	$board{color}->{brown}=$board{img}->colorAllocate(128,128,0);

	$board{img}->filledRectangle($board{min},$board{min},$board{max},$board{max},$board{color}->{brown});

	for (my $i=0; $i<$self->{lines}; $i++) {
		$board{img}->line(
			$board{grid}->{min},$board{grid}->{min}+($i*$board{grid}->{space}),
			$board{grid}->{max},$board{grid}->{min}+($i*$board{grid}->{space}),
			$board{color}->{black}
		);
	}
	for (my $i=0; $i<$self->{lines}; $i++) {
		$board{img}->line(
			$board{grid}->{min}+($i*$board{grid}->{space}),$board{grid}->{min},
			$board{grid}->{min}+($i*$board{grid}->{space}),$board{grid}->{max},
			$board{color}->{black}
		);
	}

# create image of black stone

	$stone{(BLACK)}{dia}=int($board{grid}->{space} * .9);
	$stone{(BLACK)}{img}=GD::Image->new($stone{(BLACK)}{dia},$stone{(BLACK)}{dia});
	$stone{(BLACK)}{color}->{trans}=$stone{(BLACK)}{img}->colorAllocate(1,1,1);
	$stone{(BLACK)}{color}->{black}=$stone{(BLACK)}{img}->colorAllocate(1,1,1);
	$stone{(BLACK)}{img}->arc(
		$stone{(BLACK)}{dia}/2,
		$stone{(BLACK)}{dia}/2,
		$stone{(BLACK)}{dia},
		$stone{(BLACK)}{dia},
		0,
		360,
		$stone{(BLACK)}{color}->{black}
	);
	$stone{(BLACK)}{img}->fill(
		$stone{(BLACK)}{dia}/2,
		$stone{(BLACK)}{dia}/2,
		$stone{(BLACK)}{color}->{black}
	);
	$stone{(BLACK)}{img}->transparent($stone{(BLACK)}{color}->{trans});

# create image of white stone

	$stone{(WHITE)}{dia}=int($board{grid}->{space} * .9);
	$stone{(WHITE)}{img}=GD::Image->new($stone{(WHITE)}{dia},$stone{(WHITE)}{dia});
	$stone{(WHITE)}{color}->{trans}=$stone{(WHITE)}{img}->colorAllocate(1,1,1);
	$stone{(WHITE)}{color}->{black}=$stone{(WHITE)}{img}->colorAllocate(0,0,0);
	$stone{(WHITE)}{color}->{white}=$stone{(WHITE)}{img}->colorAllocate(255,255,255);
	$stone{(WHITE)}{img}->arc(
		$stone{(WHITE)}{dia}/2,
		$stone{(WHITE)}{dia}/2,
		$stone{(WHITE)}{dia},
		$stone{(WHITE)}{dia},
		0,
		360,
		$stone{(WHITE)}{color}->{black}
	);
	$stone{(WHITE)}{img}->fill(
		$stone{(WHITE)}{dia}/2,
		$stone{(WHITE)}{dia}/2,
		$stone{(WHITE)}{color}->{white}
	);
	$stone{(WHITE)}{img}->transparent($stone{(WHITE)}{color}->{trans});

# create image of star point

	$star{dia}=int($size/75)+1;
	$star{img}=GD::Image->new($star{dia},$star{dia});
	$star{color}->{trans}=$star{img}->colorAllocate(1,1,1);
	$star{color}->{black}=$star{img}->colorAllocate(0,0,0);
	$star{img}->arc(
		$star{dia}/2,
		$star{dia}/2,
		$star{dia},
		$star{dia},
		0,
		360,
		$star{color}->{black}
	);
	$star{img}->fill(
		$star{dia}/2,
		$star{dia}/2,
		$star{color}->{black}
	);
	$star{img}->transparent($star{color}->{trans});

# place star points

	foreach my $starpoint (@{_stars($self->{lines})}) {
		$board{img}->copy(
			$star{img},
			$board{grid}->{min}+(($starpoint->[0]-1) * $board{grid}->{space})-($star{dia}/2),
			$board{grid}->{min}+(($starpoint->[1]-1) * $board{grid}->{space})-($star{dia}/2),
			0,
			0,
			$star{dia},
			$star{dia}
		);
	}
	
# stone-placing sub
	
	sub png_place_stone {
		my ($color, $x, $y) = @_;

		$board{img}->copy(
			$stone{$color}{img},
			$board{grid}->{min}+(($x-1) * $board{grid}->{space})-($stone{$color}{dia}/2),
			$board{grid}->{min}+(($y-1) * $board{grid}->{space})-($stone{$color}{dia}/2),
			0,
			0,
			$stone{$color}{dia},
			$stone{$color}{dia}
		);
	}

# place a white and black stone

	png_place_stone(BLACK,5,5);
	png_place_stone(BLACK,5,6);
	png_place_stone(WHITE,6,5);
	png_place_stone(WHITE,$self->{lines},$self->{lines});

# return image

	return $board{img}->png;

}

"Butterflies.";
