#!/usr/bin/perl

use strict;
use lib qw(/home/samael/code/perl);
use Games::Go::Board;

use vars qw[ $go ];


$go=Games::Go::Board->new($ARGV[0] or 19);

if (defined $go) {
	print $go->text();
} else {
	print "Error!\n\n";

}

