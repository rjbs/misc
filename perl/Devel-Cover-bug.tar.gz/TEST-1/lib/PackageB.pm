package PackageA;

use strict;
use warnings;

sub cover_this_please {
  my $y = 20 * 20;
}
1;
