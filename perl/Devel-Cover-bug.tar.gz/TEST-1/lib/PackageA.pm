package PackageA;

use strict;
use warnings;

sub cover_this_please {
  my $x = 10 * 2;
}
1;
